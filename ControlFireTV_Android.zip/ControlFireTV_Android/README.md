# Control Fire TV — aplicación Android

**Estado:** proyecto fuente completo, núcleo del protocolo ADB probado localmente en Java; **APK aún no compilado en este entorno** porque aquí no está instalado Android SDK. Para obtener la APK, sigue la sección «Compilar en Windows». No se ha podido validar la interfaz en un teléfono real ni la conectividad a un Fire Stick físico.

## Para qué sirve

Aplicación Android que controla un Amazon Fire TV Stick 2ª generación con **ADB por TCP (puerto 5555)**, sin enviar comandos a un PC. El teléfono puede compartir internet con el Fire Stick, si el fabricante/Android permite comunicación desde el anfitrión del hotspot hacia los clientes. Esa condición debe probarse en el teléfono real; **no está garantizada**.

**Funciones implementadas**

- Conexión directa por IP, puerto personalizable y estado de conexión.
- Autenticación ADB RSA de 2048 bits con clave propia del teléfono, guardada en archivos privados de la aplicación.
- Control direccional, OK, Atrás, Inicio, Menú.
- Reproducir/pausar, retroceder, avanzar, volumen y silencio (si el hardware permite los últimos).
- Teclado ASCII simple; letras sin acentos, números, espacio, `@`, `_`, punto y guion.
- Accesos rápidos a Netflix, YouTube, Disney+ y Pluto TV con comprobación de paquete antes de lanzar.
- Detección opcional y manual de IP en subredes privadas locales; se puede introducir IP sin escanear.
- Reutiliza una conexión ADB durante el uso; no requiere servicios permanentes en segundo plano.
- Sin anuncios, cuentas, rastreo, bibliotecas de terceros ni privilegios root.

## Tu Fire Stick — información conocida

- Modelo informado: Amazon Fire TV Stick 2ª gen., Fire OS 5 / Android API 22.
- ID ADB observado en Windows: `G070L81882930P5W`.
- Última IP reportada: `192.168.24.168`; **podría haber cambiado** al reconfigurar Wi-Fi.
- ADB 5555 activado previamente. DNS/IP se modificaron y hubo una pérdida de internet.
- El teléfono Android da acceso Wi-Fi al Fire Stick (hotspot).

⚠️ **No olvides ni cambies el Wi-Fi del Fire Stick para utilizar la app**. La aplicación solo envía comandos ADB, no reconfigura la red.

## Compilar en Windows (con Android Studio instalado)

1. Instala [Android Studio](https://developer.android.com/studio), abre **SDK Manager** e instala **Android SDK Platform 35** y **SDK Build-Tools**.
2. Instala JDK 17 o superior (Android Studio incluye un JDK integrado) o configura `JAVA_HOME` a un JDK compatible.
3. Extrae el ZIP de este proyecto y abre la carpeta `ControlFireTV_Android` en Android Studio (**Open**).
4. Permite que Android Studio descargue y sincronice Gradle Android Gradle Plugin 8.7.3. Si pregunta por el SDK, indícale su ruta.
5. En Android Studio selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. La APK aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.
7. Alternativamente, haz doble clic en `CREAR_APK_WINDOWS.bat` desde Windows. Este script utiliza Gradle instalado o descarga Gradle 8.9, compila `assembleDebug` y copia una APK a `ControlFireTV-debug.apk` en la raíz del proyecto.
8. Transfiere esa APK al **celular Android**, no al Fire Stick. Para probarla puedes instalarla desde el administrador de archivos del teléfono, concediendo permiso de instalación solo para ese archivo/aplicación de confianza.

Nota: El proyecto no incluye archivos binarios de Android SDK, el archivo binario estándar `gradle-wrapper.jar` ni APK fingidas. La compilación requiere que Android Studio o Android SDK estén instalados en Windows.

## Primera conexión desde el celular

1. Comprueba que el Fire Stick esté conectado al hotspot del teléfono y que las opciones ADB estén activadas.
2. Abre Control Fire TV y escribe la **IP actual del Fire Stick**. El valor precargado es la última IP histórica; si cambió, usa **Buscar IP** o mírala en Configuración de Fire TV > Acerca de > Red.
3. Pulsa **Conectar**; la primera conexión desde el teléfono generará una clave RSA diferente de la clave del PC.
4. **Acepta la autorización ADB en el televisor**. Si no tienes el control original, puede ser necesario usar el control del televisor (HDMI-CEC) o una sesión ADB ya autorizada desde Windows para pulsar OK en el aviso. No se omite ni se falsifica la autorización.
5. Una vez autorizado, envía flechas y verifica el botón Menú. Después apaga el PC y vuelve a probar para comprobar que el teléfono controla el Stick directamente.

Si el teléfono no puede comunicarse con los clientes de su propio hotspot, el error puede deberse a restricciones de Android o del fabricante. La aplicación te lo indicará; considera conectar teléfono y Fire Stick a una misma red Wi-Fi convencional.

## Seguridad y limitaciones

- ADB clásico en el puerto 5555 **no cifra los comandos**. Úsalo solo en redes privadas y de confianza.
- La clave privada RSA queda guardada en el almacenamiento privado del APK, sin exportarla ni hacer copias de seguridad mediante Android Backup. Es suficiente para esta versión local; se recomienda migrar a Android Keystore para mayor protección en una siguiente versión.
- No hay servidor remoto, publicidad, métricas ni llamadas a internet externas desde esta aplicación; solo conexiones IP locales hacia ADB.
- Los códigos de volumen/power dependen del modelo y de HDMI-CEC. Puede ser que el volumen no funcione, aun si se envían los códigos correctamente.
- El teclado usa el comando ADB clásico `input text`; no soporta caracteres con acentos ni emojis.
- La aplicación no anula publicidad del launcher Amazon; su objetivo es servir como control remoto.
- Fire OS puede rechazar operaciones privilegiadas. La aplicación no intenta desactivar ni eliminar paquetes protegidos.
- Si el Fire Stick cambia de IP, se debe reconectar manualmente. No se incluye conexión mediante PIN de la app oficial de Amazon.

## Pruebas realizadas aquí

Se ejecutó `scripts/probar-protocolo.sh` con JDK 21, utilizando un servidor ADB simulado. Prueba el protocolo de paquetes, desafío RSA SHA1, estructura de clave pública Android y ejecución/respuesta de comandos `shell`.

**Resultado: `PASS`**. Esto **no equivale** a haber compilado un APK ni a haber probado conexión real con el Fire Stick.

## Referencias

- [Amazon Developer — Connect to Fire TV Through ADB](https://developer.amazon.com/docs/fire-tv/connecting-adb-to-device.html)
- [Android — KeyEvent](https://developer.android.com/reference/android/view/KeyEvent)
- [Android Studio — compilación de aplicaciones](https://developer.android.com/build)
