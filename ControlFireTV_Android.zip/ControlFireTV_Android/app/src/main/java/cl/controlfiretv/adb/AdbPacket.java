package cl.controlfiretv.adb;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/** Classic ADB host-to-adbd TCP packet framing. Not the modern TLS pairing protocol. */
public final class AdbPacket {
    public static final int CNXN = code("CNXN");
    public static final int AUTH = code("AUTH");
    public static final int OPEN = code("OPEN");
    public static final int OKAY = code("OKAY");
    public static final int WRTE = code("WRTE");
    public static final int CLSE = code("CLSE");

    public final int command;
    public final int arg0;
    public final int arg1;
    public final byte[] data;

    public AdbPacket(int command, int arg0, int arg1, byte[] data) {
        this.command = command;
        this.arg0 = arg0;
        this.arg1 = arg1;
        this.data = data == null ? new byte[0] : data;
    }

    public static int code(String letters) {
        if (letters.length() != 4) throw new IllegalArgumentException("4-byte command required");
        byte[] b = letters.getBytes(StandardCharsets.US_ASCII);
        return (b[0] & 255) | ((b[1] & 255) << 8) | ((b[2] & 255) << 16) | ((b[3] & 255) << 24);
    }

    public static byte[] utf8(String text) { return text.getBytes(StandardCharsets.UTF_8); }

    public void write(OutputStream out) throws IOException {
        int checksum = 0;
        for (byte item : data) checksum += item & 0xFF;
        ByteBuffer header = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        header.putInt(command).putInt(arg0).putInt(arg1).putInt(data.length)
                .putInt(checksum).putInt(command ^ -1);
        out.write(header.array());
        out.write(data);
        out.flush();
    }

    public static AdbPacket read(InputStream in) throws IOException {
        byte[] headerData = readFully(in, 24);
        ByteBuffer header = ByteBuffer.wrap(headerData).order(ByteOrder.LITTLE_ENDIAN);
        int cmd = header.getInt();
        int arg0 = header.getInt();
        int arg1 = header.getInt();
        int length = header.getInt();
        int checksum = header.getInt();
        int magic = header.getInt();
        if (magic != (cmd ^ -1)) throw new IOException("ADB: encabezado inválido");
        if (length < 0 || length > 1024 * 1024) throw new IOException("ADB: paquete demasiado grande");
        byte[] data = readFully(in, length);
        int calculated = 0;
        for (byte value : data) calculated += value & 0xFF;
        if (calculated != checksum) throw new IOException("ADB: suma de verificación incorrecta");
        return new AdbPacket(cmd, arg0, arg1, data);
    }

    private static byte[] readFully(InputStream input, int length) throws IOException {
        byte[] data = new byte[length];
        int pos = 0;
        while (pos < length) {
            int n = input.read(data, pos, length - pos);
            if (n < 0) throw new EOFException("ADB: conexión cerrada");
            pos += n;
        }
        return data;
    }
}
