package cl.controlfiretv.net;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Optional user-initiated bounded private /24 port search. Not a dependency for manual IP. */
public final class LanScanner {
    private LanScanner() { }

    public static List<String> scan(int port) throws Exception {
        Set<String> prefixes = new LinkedHashSet<>();
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        if (interfaces != null) {
            while (interfaces.hasMoreElements()) {
                NetworkInterface net = interfaces.nextElement();
                if (!net.isUp() || net.isLoopback()) continue;
                Enumeration<InetAddress> addresses = net.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    if (!(address instanceof Inet4Address) || !address.isSiteLocalAddress()) continue;
                    String value = address.getHostAddress();
                    int last = value.lastIndexOf('.');
                    if (last > 0) prefixes.add(value.substring(0, last + 1));
                }
            }
        }
        if (prefixes.isEmpty()) throw new IllegalStateException(
                "No se detectó una red privada. Introduce manualmente la IP del Fire Stick.");
        // Keep scans small and intentionally user-driven. At most two networks, 254 hosts each.
        ExecutorService pool = Executors.newFixedThreadPool(24);
        try {
            List<Future<String>> checks = new ArrayList<>();
            int networks = 0;
            for (String prefix : prefixes) {
                if (networks++ >= 2) break;
                for (int host = 1; host < 255; host++) {
                    final String target = prefix + host;
                    checks.add(pool.submit(new Callable<String>() {
                        @Override public String call() {
                            try (Socket socket = new Socket()) {
                                socket.connect(new InetSocketAddress(target, port), 320);
                                return target;
                            } catch (Exception ignored) {
                                return null;
                            }
                        }
                    }));
                }
            }
            List<String> results = new ArrayList<>();
            for (Future<String> check : checks) {
                String ip = check.get(20, TimeUnit.SECONDS);
                if (ip != null) results.add(ip);
            }
            Collections.sort(results);
            return results;
        } finally {
            pool.shutdownNow();
        }
    }
}
