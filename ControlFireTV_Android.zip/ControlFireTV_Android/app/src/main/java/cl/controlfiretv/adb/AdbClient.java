package cl.controlfiretv.adb;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;

/** One persistent authenticated TCP connection; use from a single background worker. */
public final class AdbClient implements Closeable {
    private Socket socket;
    private InputStream in;
    private OutputStream out;
    private int localId = 1;
    private boolean connected;

    public synchronized void connect(String ip, int port, AdbIdentity identity) throws Exception {
        close();
        socket = new Socket();
        try {
            socket.connect(new InetSocketAddress(ip, port), 4000);
            socket.setTcpNoDelay(true);
            socket.setSoTimeout(55000); // first authorization popup may need time
            in = socket.getInputStream();
            out = socket.getOutputStream();
            send(AdbPacket.CNXN, 0x01000000, 4096, AdbPacket.utf8("host::\u0000"));
            boolean sentSignature = false, sentPublicKey = false;
            for (int i = 0; i < 10; i++) {
                AdbPacket p = AdbPacket.read(in);
                if (p.command == AdbPacket.CNXN) {
                    connected = true;
                    socket.setSoTimeout(9000);
                    return;
                }
                if (p.command != AdbPacket.AUTH || p.arg0 != 1) {
                    throw new IOException("Respuesta ADB inesperada durante autenticación");
                }
                if (!sentSignature) {
                    send(AdbPacket.AUTH, 2, 0, identity.signToken(p.data));
                    sentSignature = true;
                } else if (!sentPublicKey) {
                    send(AdbPacket.AUTH, 3, 0, identity.publicKeyForAdb());
                    sentPublicKey = true;
                } else {
                    throw new IOException("La clave ADB no fue autorizada en el televisor");
                }
            }
            throw new IOException("Demasiados intentos de autorización ADB");
        } catch (SocketTimeoutException e) {
            close();
            throw new IOException("Tiempo agotado. Revisa y acepta la autorización ADB en el TV", e);
        } catch (Exception e) {
            close();
            throw e;
        }
    }

    public synchronized boolean isConnected() {
        return connected && socket != null && !socket.isClosed();
    }

    /** Returns stdout/stderr (limited). Do not pass untrusted raw shell commands. */
    public synchronized String shell(String command) throws IOException {
        if (!isConnected()) throw new IOException("Primero conecta el Fire TV");
        if (command.indexOf('\u0000') >= 0) throw new IllegalArgumentException("Comando inválido");
        int local = localId++;
        send(AdbPacket.OPEN, local, 0, AdbPacket.utf8("shell:" + command + "\u0000"));
        int remote = 0;
        boolean opened = false;
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        try {
            for (int i = 0; i < 200; i++) {
                AdbPacket p = AdbPacket.read(in);
                if (p.arg1 != local && p.command != AdbPacket.CNXN) {
                    continue;
                }
                if (p.command == AdbPacket.OKAY) {
                    if (!opened) {
                        opened = true;
                        remote = p.arg0;
                    }
                } else if (p.command == AdbPacket.WRTE) {
                    if (remote == 0) remote = p.arg0;
                    if (result.size() + p.data.length <= 32768) result.write(p.data);
                    send(AdbPacket.OKAY, local, remote, new byte[0]);
                } else if (p.command == AdbPacket.CLSE) {
                    if (remote == 0) remote = p.arg0;
                    if (remote != 0) send(AdbPacket.CLSE, local, remote, new byte[0]);
                    return result.toString("UTF-8");
                } else if (p.command == AdbPacket.AUTH) {
                    throw new IOException("La sesión ADB perdió autorización");
                }
            }
            throw new IOException("El comando ADB tardó demasiado");
        } catch (IOException e) {
            close();
            throw e;
        }
    }

    private void send(int command, int arg0, int arg1, byte[] bytes) throws IOException {
        new AdbPacket(command, arg0, arg1, bytes).write(out);
    }

    @Override public synchronized void close() {
        connected = false;
        if (socket != null) { try { socket.close(); } catch (IOException ignored) { } }
        socket = null;
        in = null;
        out = null;
    }
}
