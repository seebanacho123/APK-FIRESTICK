package cl.controlfiretv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import cl.controlfiretv.adb.AdbClient;
import cl.controlfiretv.adb.AdbIdentity;
import cl.controlfiretv.net.LanScanner;

/** Single-screen, no telemetry, no services, no external UI dependencies. */
public final class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(12, 17, 28);
    private static final int SURFACE = Color.rgb(25, 33, 49);
    private static final int SURFACE_ALT = Color.rgb(37, 48, 70);
    private static final int ACCENT = Color.rgb(79, 155, 241);
    private static final int WHITE = Color.rgb(241, 246, 252);
    private static final int MUTED = Color.rgb(158, 176, 197);
    private static final int SUCCESS = Color.rgb(92, 212, 159);
    private static final int WARNING = Color.rgb(246, 194, 93);

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ExecutorService scanner = Executors.newSingleThreadExecutor();
    private final AdbClient adb = new AdbClient();
    private SharedPreferences prefs;
    private TextView statusText;
    private EditText ipField;
    private EditText portField;
    private Button connectButton;
    private String connectedIp = "";
    private int connectedPort = 5555;
    private boolean busy;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("firetv_control", MODE_PRIVATE);
        buildInterface();
    }

    private int dp(float x) { return (int) (x * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private TextView text(String content, int sp, int color, boolean bold) {
        TextView label = new TextView(this);
        label.setText(content);
        label.setTextSize(sp);
        label.setTextColor(color);
        if (bold) label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return label;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }
    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private void addGap(LinearLayout parent, int px) {
        View spacer = new View(this);
        parent.addView(spacer, new LinearLayout.LayoutParams(1, dp(px)));
    }

    private Button button(String title, int color, Runnable click) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextColor(WHITE);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(bg(color, 14));
        b.setPadding(dp(7), dp(8), dp(7), dp(8));
        b.setOnClickListener(v -> { haptic(); click.run(); });
        return b;
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout root = column();
        root.setPadding(dp(18), dp(18), dp(18), dp(26));
        scroll.addView(root);
        setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                scroll.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }

        root.addView(text("CONTROL  /  FIRE TV", 12, ACCENT, true));
        addGap(root, 6);
        root.addView(text("Tu control, sin anuncios", 25, WHITE, true));
        addGap(root, 5);
        root.addView(text("Fire OS 5 · Control local por ADB", 13, MUTED, false));
        addGap(root, 20);

        LinearLayout connectionCard = column();
        connectionCard.setPadding(dp(16), dp(16), dp(16), dp(15));
        connectionCard.setBackground(bg(SURFACE, 18));
        statusText = text("● Desconectado", 15, WARNING, true);
        connectionCard.addView(statusText);
        addGap(connectionCard, 6);
        connectionCard.addView(text("IP del Fire Stick (no la IP del celular)", 12, MUTED, false));
        addGap(connectionCard, 9);
        LinearLayout ipRow = row();
        ipField = new EditText(this);
        ipField.setSingleLine(true);
        ipField.setSelectAllOnFocus(true);
        ipField.setInputType(InputType.TYPE_CLASS_PHONE);
        ipField.setTextSize(16);
        ipField.setTextColor(WHITE);
        ipField.setHintTextColor(MUTED);
        ipField.setHint("192.168.x.x");
        ipField.setBackground(bg(SURFACE_ALT, 10));
        ipField.setPadding(dp(12), dp(10), dp(12), dp(10));
        ipField.setText(prefs.getString("ip", "192.168.24.168"));
        ipRow.addView(ipField, new LinearLayout.LayoutParams(0, dp(51), 4));
        portField = new EditText(this);
        portField.setSingleLine(true);
        portField.setInputType(InputType.TYPE_CLASS_NUMBER);
        portField.setTextColor(WHITE);
        portField.setTextSize(16);
        portField.setGravity(Gravity.CENTER);
        portField.setBackground(bg(SURFACE_ALT, 10));
        portField.setText(prefs.getString("port", "5555"));
        LinearLayout.LayoutParams portParams = new LinearLayout.LayoutParams(0, dp(51), 1.2f);
        portParams.leftMargin = dp(8);
        ipRow.addView(portField, portParams);
        connectionCard.addView(ipRow);
        addGap(connectionCard, 10);
        LinearLayout actionRow = row();
        connectButton = button("Conectar", ACCENT, this::connect);
        actionRow.addView(connectButton, new LinearLayout.LayoutParams(0, dp(48), 2));
        Button scanButton = button("Buscar IP", SURFACE_ALT, this::scanNetwork);
        LinearLayout.LayoutParams scanParams = new LinearLayout.LayoutParams(0, dp(48), 1.5f);
        scanParams.leftMargin = dp(10);
        actionRow.addView(scanButton, scanParams);
        connectionCard.addView(actionRow);
        addGap(connectionCard, 10);
        connectionCard.addView(text("La primera conexión puede pedir autorizar la clave ADB en el televisor.", 11, MUTED, false));
        root.addView(connectionCard);
        addGap(root, 22);

        TextView remoteTitle = text("NAVEGACIÓN", 12, MUTED, true);
        root.addView(remoteTitle);
        addGap(root, 14);
        FrameLayout pad = new FrameLayout(this);
        LinearLayout.LayoutParams padLp = new LinearLayout.LayoutParams(dp(266), dp(248));
        padLp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(pad, padLp);
        directional(pad, "▲", 19, 90, 61, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0);
        directional(pad, "◀", 21, 72, 85, Gravity.CENTER_VERTICAL | Gravity.LEFT, 0, 0);
        directional(pad, "OK", 23, 93, 93, Gravity.CENTER, 0, 0);
        directional(pad, "▶", 22, 72, 85, Gravity.CENTER_VERTICAL | Gravity.RIGHT, 0, 0);
        directional(pad, "▼", 20, 90, 61, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        addGap(root, 18);

        LinearLayout mainKeys = row();
        labeledKey(mainKeys, "↶  Atrás", 4, 1, SURFACE_ALT);
        labeledKey(mainKeys, "⌂  Inicio", 3, 1, ACCENT);
        labeledKey(mainKeys, "☰  Menú", 82, 1, SURFACE_ALT);
        root.addView(mainKeys);
        addGap(root, 12);
        LinearLayout media = row();
        labeledKey(media, "⏪", 89, 1, SURFACE);
        labeledKey(media, "⏯", 85, 1, SURFACE_ALT);
        labeledKey(media, "⏩", 90, 1, SURFACE);
        root.addView(media);
        addGap(root, 10);
        LinearLayout volume = row();
        labeledKey(volume, "VOL −", 25, 1, SURFACE);
        labeledKey(volume, "Silencio", 164, 1, SURFACE);
        labeledKey(volume, "VOL +", 24, 1, SURFACE);
        root.addView(volume);
        addGap(root, 18);
        root.addView(text("APLICACIONES", 12, MUTED, true));
        addGap(root, 10);
        LinearLayout appsA = row();
        appKey(appsA, "Netflix", "com.netflix.ninja");
        appKey(appsA, "YouTube", "com.amazon.firetv.youtube");
        root.addView(appsA);
        addGap(root, 8);
        LinearLayout appsB = row();
        appKey(appsB, "Disney+", "com.disney.disneyplus");
        appKey(appsB, "Pluto TV", "tv.pluto.android");
        root.addView(appsB);
        addGap(root, 18);

        LinearLayout keyboardCard = column();
        keyboardCard.setBackground(bg(SURFACE, 16));
        keyboardCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        keyboardCard.addView(text("TECLADO RÁPIDO", 12, MUTED, true));
        addGap(keyboardCard, 8);
        EditText typingField = new EditText(this);
        typingField.setSingleLine(true);
        typingField.setTextColor(WHITE);
        typingField.setTextSize(15);
        typingField.setHint("Texto sin tildes ni símbolos especiales");
        typingField.setHintTextColor(MUTED);
        typingField.setBackground(bg(SURFACE_ALT, 10));
        typingField.setPadding(dp(12), dp(11), dp(12), dp(11));
        keyboardCard.addView(typingField, new LinearLayout.LayoutParams(-1, dp(52)));
        addGap(keyboardCard, 10);
        LinearLayout typingButtons = row();
        Button type = button("Enviar texto", ACCENT, () -> sendText(typingField.getText().toString()));
        typingButtons.addView(type, new LinearLayout.LayoutParams(0, dp(44), 2));
        Button enter = button("Enter ↵", SURFACE_ALT, () -> sendKey(66));
        LinearLayout.LayoutParams enterLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        enterLp.leftMargin = dp(8);
        typingButtons.addView(enter, enterLp);
        keyboardCard.addView(typingButtons);
        root.addView(keyboardCard);
        addGap(root, 14);
        Button help = button("Ayuda y recuperación de conexión", SURFACE, this::showHelp);
        root.addView(help, new LinearLayout.LayoutParams(-1, dp(50)));
        addGap(root, 11);
        root.addView(text("Sin publicidad, cuentas ni telemetría · El tráfico ADB local no está cifrado; utiliza una red de confianza.", 11, MUTED, false));
    }

    private void directional(FrameLayout pad, String title, int key, int width, int height,
                             int gravity, int x, int y) {
        Button b = button(title, key == 23 ? ACCENT : SURFACE_ALT, () -> sendKey(key));
        b.setTextSize(key == 23 ? 22 : 26);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(width), dp(height), gravity);
        lp.leftMargin = dp(x);
        lp.topMargin = dp(y);
        pad.addView(b, lp);
    }

    private void labeledKey(LinearLayout parent, String title, int key, float weight, int background) {
        Button b = button(title, background, () -> sendKey(key));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(62), weight);
        if (parent.getChildCount() > 0) lp.leftMargin = dp(8);
        parent.addView(b, lp);
    }

    private void appKey(LinearLayout parent, String label, String pkg) {
        Button b = button(label, SURFACE, () -> launchApp(pkg));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(47), 1);
        if (parent.getChildCount() > 0) lp.leftMargin = dp(8);
        parent.addView(b, lp);
    }

    private void launchApp(String pkg) {
        if (!adb.isConnected()) { alert("Primero conecta el Fire Stick."); return; }
        // The package name comes exclusively from this app's hard-coded allowlist.
        worker.execute(() -> {
            try {
                String path = adb.shell("pm path " + pkg);
                if (!path.contains("package:")) {
                    runOnUiThread(() -> alert("La aplicación no está instalada actualmente en el Fire Stick."));
                    return;
                }
                String result = adb.shell("monkey -p " + pkg + " -c android.intent.category.LAUNCHER 1");
                if (result.contains("aborted") || result.contains("No activities found")) {
                    runOnUiThread(() -> alert("Fire OS no pudo abrir la aplicación: " + result));
                }
            } catch (Exception e) {
                adb.close();
                runOnUiThread(() -> { setStatus("● Conexión perdida", WARNING); alert(friendly(e)); });
            }
        });
    }

    private String getIp() {
        String ip = ipField.getText().toString().trim();
        String[] octets = ip.split("\\.");
        if (octets.length != 4) throw new IllegalArgumentException("Introduce una dirección IPv4 válida");
        for (String part : octets) {
            int value;
            try { value = Integer.parseInt(part); } catch (Exception e) {
                throw new IllegalArgumentException("Dirección IPv4 inválida");
            }
            if (value < 0 || value > 255 || part.isEmpty()) throw new IllegalArgumentException("Dirección IPv4 inválida");
        }
        return ip;
    }

    private int getPort() {
        int port;
        try { port = Integer.parseInt(portField.getText().toString().trim()); }
        catch (Exception ignored) { throw new IllegalArgumentException("Puerto inválido"); }
        if (port < 1 || port > 65535) throw new IllegalArgumentException("Puerto fuera de rango");
        return port;
    }

    private void connect() {
        if (busy) return;
        if (adb.isConnected()) {
            worker.execute(() -> { adb.close(); runOnUiThread(() -> setStatus("● Desconectado", WARNING)); });
            return;
        }
        final String ip;
        final int port;
        try { ip = getIp(); port = getPort(); }
        catch (Exception e) { alert(e.getMessage()); return; }
        busy = true;
        setStatus("◌ Conectando o esperando autorización…", WARNING);
        worker.execute(() -> {
            try {
                AdbIdentity identity = AdbIdentity.loadOrCreate(new File(getFilesDir(), "adb-keys"));
                adb.connect(ip, port, identity);
                connectedIp = ip;
                connectedPort = port;
                prefs.edit().putString("ip", ip).putString("port", String.valueOf(port)).apply();
                runOnUiThread(() -> setStatus("● Conectado a " + ip, SUCCESS));
            } catch (Exception e) {
                runOnUiThread(() -> { setStatus("● Sin conexión", WARNING); alert(friendly(e)); });
            } finally {
                busy = false;
            }
        });
    }

    private String friendly(Exception e) {
        String raw = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        String lower = raw.toLowerCase(Locale.ROOT);
        if (lower.contains("refused") || lower.contains("rechaz"))
            return "El puerto ADB 5555 no está escuchando. Comprueba Depuración ADB y la IP.\n\n" + raw;
        if (lower.contains("timeout") || lower.contains("timed out") || lower.contains("tiempo"))
            return "No se obtuvo respuesta. Comprueba si el teléfono puede acceder a los clientes de su hotspot y revisa la autorización ADB.\n\n" + raw;
        return raw;
    }

    private void setStatus(String message, int color) {
        statusText.setText(message);
        statusText.setTextColor(color);
        connectButton.setText(adb.isConnected() ? "Desconectar" : "Conectar");
    }

    private void sendKey(int code) {
        if (!adb.isConnected()) { alert("Primero pulsa Conectar y autoriza el dispositivo en tu TV."); return; }
        worker.execute(() -> {
            try { adb.shell("input keyevent " + code); }
            catch (Exception e) { adb.close(); runOnUiThread(() -> {
                setStatus("● Conexión perdida", WARNING);
                alert("No se pudo enviar el botón: " + friendly(e));
            }); }
        });
    }

    private void sendText(String raw) {
        if (!adb.isConnected()) { alert("Primero conecta el Fire Stick."); return; }
        if (raw.length() == 0 || raw.length() > 120 || !raw.matches("[a-zA-Z0-9 ._@-]+")) {
            alert("Esta versión admite hasta 120 caracteres ASCII: letras sin tildes, números, espacios, punto, guion, _ y @.");
            return;
        }
        // %s is Android 'input text' space escaping. Whitelist prevents shell injection.
        String safe = raw.replace(" ", "%s");
        worker.execute(() -> {
            try { adb.shell("input text " + safe); }
            catch (Exception e) { adb.close(); runOnUiThread(() -> { setStatus("● Conexión perdida", WARNING); alert(friendly(e)); }); }
        });
    }

    private void scanNetwork() {
        final int port;
        try { port = getPort(); }
        catch (Exception e) { alert(e.getMessage()); return; }
        setStatus("◌ Buscando en la red local…", WARNING);
        scanner.execute(() -> {
            try {
                List<String> found = LanScanner.scan(port);
                runOnUiThread(() -> {
                    setStatus(adb.isConnected() ? "● Conectado" : "● Búsqueda finalizada", adb.isConnected() ? SUCCESS : MUTED);
                    if (found.isEmpty()) { alert("No se encontró ningún puerto ADB abierto. Comprueba el hotspot y prueba con la IP manual."); return; }
                    String[] items = found.toArray(new String[0]);
                    new AlertDialog.Builder(this).setTitle("Direcciones encontradas")
                            .setItems(items, (dialog, which) -> { ipField.setText(items[which]); connect(); })
                            .setNegativeButton("Cancelar", null).show();
                });
            } catch (Exception e) { runOnUiThread(() -> { setStatus("● Sin conexión", WARNING); alert(friendly(e)); }); }
        });
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Ayuda para conectar")
                .setMessage("1. Activa Depuración ADB en Fire TV.\n\n"
                        + "2. Conecta el Fire Stick al hotspot Android y averigua su IP actual. "
                        + "El valor inicial 192.168.24.168 es solo histórico.\n\n"
                        + "3. Pulsa Conectar. La primera vez debes autorizar la clave RSA "
                        + "desde el televisor, posiblemente con un control alternativo o ADB ya autorizado desde Windows.\n\n"
                        + "4. Si Android restringe conexiones desde el teléfono a sus clientes de hotspot, "
                        + "la app no podrá controlarlo por esa ruta; prueba una red Wi-Fi común.\n\n"
                        + "5. No modifiques el DNS ni olvides la red desde esta aplicación.\n\n"
                        + "El protocolo ADB clásico no cifra el tráfico. Solo utilizar en redes de confianza.")
                .setPositiveButton("Entendido", null).show();
    }

    private void alert(String message) {
        new AlertDialog.Builder(this).setTitle("Control Fire TV")
                .setMessage(message).setPositiveButton("Aceptar", null).show();
    }

    private void haptic() {
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) vib.vibrate(VibrationEffect.createOneShot(14, 60));
        } catch (Exception ignored) { }
    }

    @Override protected void onDestroy() {
        adb.close();
        worker.shutdownNow();
        scanner.shutdownNow();
        super.onDestroy();
    }
}
