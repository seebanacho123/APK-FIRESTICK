package cl.controlfiretv.adb;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.Cipher;

/** RSA auth for classic (pre-pairing) adbd. Keys live in Android application-private files. */
public final class AdbIdentity {
    private static final byte[] SHA1_DIGEST_INFO = hex("3021300906052b0e03021a05000414");
    private static final BigInteger TWO32 = BigInteger.ONE.shiftLeft(32);
    private final PrivateKey privateKey;
    private final RSAPublicKey publicKey;

    private AdbIdentity(PrivateKey privateKey, RSAPublicKey publicKey) {
        this.privateKey = privateKey;
        this.publicKey = publicKey;
    }

    public static AdbIdentity loadOrCreate(File dir) throws Exception {
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("No se pudo crear directorio de claves");
        File priv = new File(dir, "adb_private.pk8");
        File pub = new File(dir, "adb_public.x509");
        KeyFactory factory = KeyFactory.getInstance("RSA");
        if (priv.isFile() && pub.isFile()) {
            PrivateKey p = factory.generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(priv.toPath())));
            PublicKey k = factory.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(pub.toPath())));
            return new AdbIdentity(p, (RSAPublicKey) k);
        }
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair pair = g.generateKeyPair();
        // filesDir is private to the app sandbox; never place these keys on external storage.
        Files.write(priv.toPath(), pair.getPrivate().getEncoded());
        Files.write(pub.toPath(), pair.getPublic().getEncoded());
        return new AdbIdentity(pair.getPrivate(), (RSAPublicKey) pair.getPublic());
    }

    /** adbd sends a 20-byte SHA1 challenge. Sign its SHA1 DigestInfo *without hashing again*. */
    public byte[] signToken(byte[] token) throws Exception {
        if (token.length != 20) throw new IOException("Desafío ADB inesperado");
        byte[] digestInfo = new byte[SHA1_DIGEST_INFO.length + token.length];
        System.arraycopy(SHA1_DIGEST_INFO, 0, digestInfo, 0, SHA1_DIGEST_INFO.length);
        System.arraycopy(token, 0, digestInfo, SHA1_DIGEST_INFO.length, token.length);
        Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        c.init(Cipher.ENCRYPT_MODE, privateKey);
        return c.doFinal(digestInfo);
    }

    /** Android-adb public-key struct (modulus + Montgomery fields), base64 encoded plus comment. */
    public byte[] publicKeyForAdb() throws IOException {
        BigInteger n = publicKey.getModulus();
        int keyBytes = 256;
        if (n.bitLength() > 2048 || n.bitLength() < 2040)
            throw new IOException("La clave ADB debe ser RSA de 2048 bits");
        BigInteger n0 = n.and(TWO32.subtract(BigInteger.ONE));
        BigInteger n0inv = TWO32.subtract(n0.modInverse(TWO32)).mod(TWO32);
        BigInteger rr = BigInteger.ONE.shiftLeft(keyBytes * 16).mod(n);
        ByteBuffer bb = ByteBuffer.allocate(4 + 4 + keyBytes + keyBytes + 4)
                .order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(keyBytes / 4);
        bb.putInt(n0inv.intValue());
        bb.put(littleEndian(n, keyBytes));
        bb.put(littleEndian(rr, keyBytes));
        bb.putInt(publicKey.getPublicExponent().intValue());
        String key = Base64.getEncoder().encodeToString(bb.array()) + " control-firetv@android\u0000";
        return AdbPacket.utf8(key);
    }

    private static byte[] littleEndian(BigInteger num, int size) {
        byte[] encoded = num.toByteArray();
        byte[] out = new byte[size];
        for (int i = 0; i < size; i++) {
            int idx = encoded.length - 1 - i;
            if (idx >= 0) out[i] = encoded[idx];
        }
        return out;
    }

    private static byte[] hex(String source) {
        byte[] out = new byte[source.length() / 2];
        for (int i = 0; i < out.length; i++)
            out[i] = (byte) Integer.parseInt(source.substring(i * 2, i * 2 + 2), 16);
        return out;
    }
}
