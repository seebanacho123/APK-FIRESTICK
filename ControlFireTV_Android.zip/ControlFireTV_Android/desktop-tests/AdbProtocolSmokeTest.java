import cl.controlfiretv.adb.AdbClient;
import cl.controlfiretv.adb.AdbIdentity;
import cl.controlfiretv.adb.AdbPacket;

import java.io.File;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;

/** JVM-only test: validates ADB framing, RSA token signing, Android public-key encoding and shell stream. */
public final class AdbProtocolSmokeTest {
    private static volatile Throwable serverError;
    public static void main(String[] args) throws Exception {
        File keyDir = Files.createTempDirectory("firetv-keys").toFile();
        AdbIdentity identity = AdbIdentity.loadOrCreate(keyDir);
        if (identity != AdbIdentity.loadOrCreate(keyDir)) {
            // identity object differs, but keys should persist; confirm below through RSA.
        }
        byte[] token = new byte[20];
        Arrays.fill(token, (byte) 17);
        byte[] signature = identity.signToken(token);
        PublicKey key = KeyFactory.getInstance("RSA").generatePublic(
                new X509EncodedKeySpec(Files.readAllBytes(new File(keyDir, "adb_public.x509").toPath())));
        Cipher verifier = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        verifier.init(Cipher.DECRYPT_MODE, key);
        byte[] decrypted = verifier.doFinal(signature);
        require(decrypted.length == 35, "Expected SHA1 DER prefix and 20-byte token");
        require(Arrays.equals(Arrays.copyOfRange(decrypted, 15, 35), token), "Token mismatch");

        byte[] pub = identity.publicKeyForAdb();
        String pubKeyText = new String(pub, java.nio.charset.StandardCharsets.UTF_8);
        require(pubKeyText.endsWith(" control-firetv@android\u0000"), "Missing adb comment/NUL");
        byte[] pubStruct = Base64.getDecoder().decode(pubKeyText.split(" ")[0]);
        require(pubStruct.length == 524, "RSA 2048 Android public key size should be 524 bytes");
        require(ByteBuffer.wrap(pubStruct).order(ByteOrder.LITTLE_ENDIAN).getInt(0) == 64,
                "Incorrect modulus word count");
        require(ByteBuffer.wrap(pubStruct).order(ByteOrder.LITTLE_ENDIAN).getInt(520) == 65537,
                "Incorrect public exponent");

        try (ServerSocket server = new ServerSocket(0)) {
            Thread mock = new Thread(() -> {
                try (Socket s = server.accept()) {
                    s.setSoTimeout(8000);
                    AdbPacket p = AdbPacket.read(s.getInputStream());
                    require(p.command == AdbPacket.CNXN, "Missing CNXN");
                    new AdbPacket(AdbPacket.AUTH, 1, 0, token).write(s.getOutputStream());
                    p = AdbPacket.read(s.getInputStream());
                    require(p.command == AdbPacket.AUTH && p.arg0 == 2, "Missing RSA signature");
                    new AdbPacket(AdbPacket.AUTH, 1, 0, token).write(s.getOutputStream());
                    p = AdbPacket.read(s.getInputStream());
                    require(p.command == AdbPacket.AUTH && p.arg0 == 3, "Missing public key submission");
                    new AdbPacket(AdbPacket.CNXN, 0x01000000, 4096, AdbPacket.utf8("device::\u0000"))
                            .write(s.getOutputStream());
                    p = AdbPacket.read(s.getInputStream());
                    require(p.command == AdbPacket.OPEN, "Missing shell OPEN");
                    int hostId = p.arg0, deviceId = 7;
                    new AdbPacket(AdbPacket.OKAY, deviceId, hostId, new byte[0]).write(s.getOutputStream());
                    new AdbPacket(AdbPacket.WRTE, deviceId, hostId, AdbPacket.utf8("hello\n"))
                            .write(s.getOutputStream());
                    p = AdbPacket.read(s.getInputStream());
                    require(p.command == AdbPacket.OKAY && p.arg0 == hostId, "Missing WRTE ack");
                    new AdbPacket(AdbPacket.CLSE, deviceId, hostId, new byte[0]).write(s.getOutputStream());
                    p = AdbPacket.read(s.getInputStream());
                    require(p.command == AdbPacket.CLSE, "Missing CLSE ack");
                } catch (Throwable e) { serverError = e; }
            });
            mock.start();
            try (AdbClient client = new AdbClient()) {
                client.connect("127.0.0.1", server.getLocalPort(), identity);
                require(client.isConnected(), "Client did not connect");
                require(client.shell("input keyevent 82").equals("hello\n"), "Shell reply incorrect");
            }
            mock.join(12000);
            if (serverError != null) throw new AssertionError("Fake daemon failed", serverError);
            require(!mock.isAlive(), "Fake daemon did not terminate");
        }
        System.out.println("PASS: ADB protocol framing, RSA authentication and shell stream");
    }
    private static void require(boolean value, String reason) {
        if (!value) throw new AssertionError(reason);
    }
}
