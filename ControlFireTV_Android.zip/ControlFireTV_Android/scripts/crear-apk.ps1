$ErrorActionPreference = 'Stop'
$project = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$gradleVersion = '8.9'
Write-Host 'Control Fire TV - compilacion APK Android' -ForegroundColor Cyan
$androidSdk = $env:ANDROID_HOME
if (-not $androidSdk) { $androidSdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path (Join-Path $androidSdk 'platforms\android-35\android.jar'))) {
    Write-Host 'Falta Android SDK Platform 35.' -ForegroundColor Yellow
    Write-Host 'Instala Android Studio; en SDK Manager instala Android SDK Platform 35 y Build-Tools.'
    exit 1
}
$env:ANDROID_HOME = $androidSdk
if (-not $env:JAVA_HOME) {
    $studioJbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
    if (Test-Path (Join-Path $studioJbr 'bin\java.exe')) {
        $env:JAVA_HOME = $studioJbr
        $env:PATH = (Join-Path $studioJbr 'bin') + ';' + $env:PATH
    }
}
$gradle = Get-Command gradle -ErrorAction SilentlyContinue
if ($gradle) {
    $gradleBin = $gradle.Source
} else {
    $cache = Join-Path $env:LOCALAPPDATA 'ControlFireTV\build-tools'
    $home = Join-Path $cache "gradle-$gradleVersion"
    $gradleBin = Join-Path $home 'bin\gradle.bat'
    if (-not (Test-Path $gradleBin)) {
        New-Item -ItemType Directory -Path $cache -Force | Out-Null
        $archive = Join-Path $cache "gradle-$gradleVersion-bin.zip"
        if (-not (Test-Path $archive)) {
            Write-Host "Descargando Gradle $gradleVersion..."
            Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip" -OutFile $archive
        }
        Expand-Archive -Path $archive -DestinationPath $cache -Force
    }
}
Push-Location $project
try {
    & $gradleBin ':app:assembleDebug' '--no-daemon'
    if ($LASTEXITCODE -ne 0) { throw "Gradle finalizo con error $LASTEXITCODE" }
    $source = Join-Path $project 'app\build\outputs\apk\debug\app-debug.apk'
    $destination = Join-Path $project 'ControlFireTV-debug.apk'
    if (-not (Test-Path $source)) { throw 'Gradle no genero el APK esperado.' }
    Copy-Item -Path $source -Destination $destination -Force
    Write-Host "APK compilado: $destination" -ForegroundColor Green
} finally { Pop-Location }
