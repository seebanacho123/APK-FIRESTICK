#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/controlfiretv-testclasses
javac -d /tmp/controlfiretv-testclasses \
  app/src/main/java/cl/controlfiretv/adb/AdbPacket.java \
  app/src/main/java/cl/controlfiretv/adb/AdbIdentity.java \
  app/src/main/java/cl/controlfiretv/adb/AdbClient.java \
  desktop-tests/AdbProtocolSmokeTest.java
java -ea -cp /tmp/controlfiretv-testclasses AdbProtocolSmokeTest
